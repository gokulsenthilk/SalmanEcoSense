import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-testimonials',
  templateUrl: './client-testimonials.component.html',
  styleUrls: ['./client-testimonials.component.css']
})
export class ClientTestimonialsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
